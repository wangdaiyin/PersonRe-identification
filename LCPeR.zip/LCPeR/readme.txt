********************************************************************************

LCPeR:
Looser Cropped Pedestrian Recognition Dataset 

Released by the Communication and Information Security Lab at Peking University of China on 5/13/2017.  Please direct questions,comments or other feedback to Daniel(1501213964@sz.pku.edu.cn).

********************************************************************************

This dataset contains 206 pedestrian image pairs with large viewpoint changes. For each pedestrian, two compact-cropped images and two loose-cropped images are provided simultaneously, and the loose-cropped images have more background information than the compact-cropped images. 
In addition, for each image, we also provide a manual mask as ground truth.
All images are scaled to 128 x 48 pixels. 

The data are randomly collected from the surveillance videos captured by six disjoint cameras in the campus. It is more consistent with the realistic surveillance scene.

********************************************************************************
For detailed instructions on how to use and evaluate, please read and cite the following paper:

Daiyin Wang, Wenbin Yao, and Yuesheng Zhu, "A Novel Image Preprocessing Strategy for Foreground Extraction in Person Re-identification," in PCM, 2017.


********************************************************************************